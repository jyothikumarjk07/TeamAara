<?php
/**
 * Your Twitter App Info
 * How to create Twitter API key you can read here (or use google):  - http://www.gabfirethemes.com/create-twitter-api-key/
 */

// User Name
define('USER_NAME', 'nkdevv');

// Consumer Key
define('CONSUMER_KEY', 'hMJ4xIvKvoRwjry4a6TmmwIr3');
define('CONSUMER_SECRET', 'fDnpvj7xbgw2vuKEr5gC430reM1WTDAmyol6SLwjbr6cPfiwLZ');

// User Access Token
define('ACCESS_TOKEN', '2848523763-EoquJ3UfxZkmOEPPpi8CrFYzTxDYEGPwdyI8zWk');
define('ACCESS_SECRET', 'aTvW8OK0qNHxZdrz1SYLBAk09lErKZtXyJCOBaCJV1mqv');

// Cache Settings
define('CACHE_ENABLED', true);
define('CACHE_LIFETIME', 3600); // in seconds
define('HASH_SALT', md5(dirname(__FILE__)));
